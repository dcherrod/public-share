﻿function WriteLog
{
    Param ([string]$LogString)
    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $LogMessage = "$Stamp $LogString"
    Add-content $LogFile -value $LogMessage
}

$Logfile = "C:\Temp\MontserratFonts\font_install.log"
$SourceFolder = "C:\Temp\MontserratFonts"

function Install-Font {  
      param  
      (  
           [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][System.IO.FileInfo]$FontFile  
      )  
        
      #Get Font Name from the File's Extended Attributes  
      $oShell = new-object -com shell.application  
      $Folder = $oShell.namespace($FontFile.DirectoryName)  
      $Item = $Folder.Items().Item($FontFile.Name)  
      $FontName = $Folder.GetDetailsOf($Item, 21)  
      try {  
           switch ($FontFile.Extension) {  
                ".ttf" {$FontName = $FontName + [char]32 + '(TrueType)'}  
                ".otf" {$FontName = $FontName + [char]32 + '(OpenType)'}  
           }  
           $Copy = $true  
           WriteLog ('Copying' + [char]32 + $FontFile.Name + '.....')  
           Copy-Item -Path $fontFile.FullName -Destination ("C:\Windows\Fonts\" + $FontFile.Name) -Force  
           #Test if font is copied over  
           If ((Test-Path ("C:\Windows\Fonts\" + $FontFile.Name)) -eq $true) {  
                WriteLog ('Success')
           } else {  
                WriteLog ('Failed') 
           }  
           $Copy = $false  
           #Test if font registry entry exists  
           If ((Get-ItemProperty -Name $FontName -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Fonts" -ErrorAction SilentlyContinue) -ne $null) {  
                #Test if the entry matches the font file name  
                If ((Get-ItemPropertyValue -Name $FontName -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Fonts") -eq $FontFile.Name) {  
                     WriteLog ('Adding' + [char]32 + $FontName + [char]32 + 'to the registry.....')  
                     WriteLog ('Success') 
                } else {  
                     $AddKey = $true  
                     Remove-ItemProperty -Name $FontName -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Fonts" -Force  
                     WriteLog ('Adding' + [char]32 + $FontName + [char]32 + 'to the registry.....') 
                     New-ItemProperty -Name $FontName -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Fonts" -PropertyType string -Value $FontFile.Name -Force -ErrorAction SilentlyContinue | Out-Null  
                     If ((Get-ItemPropertyValue -Name $FontName -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Fonts") -eq $FontFile.Name) {  
                          WriteLog ('Success') 
                     } else {  
                          WriteLog ('Failed')
                     }  
                     $AddKey = $false  
                }  
           } else {  
                $AddKey = $true  
                WriteLog ('Adding' + [char]32 + $FontName + [char]32 + 'to the registry.....')  
                New-ItemProperty -Name $FontName -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Fonts" -PropertyType string -Value $FontFile.Name -Force -ErrorAction SilentlyContinue | Out-Null  
                If ((Get-ItemPropertyValue -Name $FontName -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Fonts") -eq $FontFile.Name) {  
                     WriteLog ('Success')   
                } else {  
                     WriteLog ('Failed')
                }  
                $AddKey = $false  
           }  
             
      } catch {  
           If ($Copy -eq $true) {  
                WriteLog ('Failed')
                $Copy = $false  
           }  
           If ($AddKey -eq $true) {  
                WriteLog ('Failed')
                $AddKey = $false  
           }  
           write-warning $_.exception.message  
      }   
 }  
   
 #Get a list of all font files relative to this script and parse through the list  
 foreach ($FontItem in (Get-ChildItem -Path $SourceFolder | Where-Object {  
                ($_.Name -like '*.ttf') -or ($_.Name -like '*.OTF')  
           })) {  
      Install-Font -FontFile $FontItem  
 }  